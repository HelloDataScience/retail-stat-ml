@echo off
rem Start Jupyter Notebook for the statistics and machine learning course.
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto novenv

rem Smart App Control (SAC) can turn itself On after Evaluation mode and then block Python.
set "SAC=0x0"
for /f "tokens=3" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy" /v VerifiedAndReputablePolicyState 2^>nul ^| find "REG_DWORD"') do set "SAC=%%A"
if /i "%SAC%"=="0x1" goto sacon

if exist "Graphviz\bin\dot.exe" set "PATH=%~dp0Graphviz\bin;%PATH%"
rem Use UTF-8 as the default text encoding (Korean Windows uses cp949).
set "PYTHONUTF8=1"
call ".venv\Scripts\activate.bat"
".venv\Scripts\python.exe" -m notebook
pause
exit /b 0

:sacon
echo [ERROR] Smart App Control is On. It blocks the Python libraries used in this course.
echo Turn it Off as shown in "Before you start" in setup_guide, then run start_jupyter.bat again.
pause
exit /b 1

:novenv
echo [ERROR] .venv folder not found in %~dp0
echo Run install.bat first.
pause
exit /b 1
