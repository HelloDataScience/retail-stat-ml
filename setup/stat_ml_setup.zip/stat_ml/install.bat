@echo off
rem Install Python 3.14 and the course libraries into .venv using uv.exe in this folder.
cd /d "%~dp0"
if not exist "uv.exe" goto nouv

rem Read the Smart App Control (SAC) state. 0 = Off, 1 = On, 2 = Evaluation.
rem Windows 10 has no SAC, so a missing value is treated as Off.
set "SAC=0x0"
for /f "tokens=3" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy" /v VerifiedAndReputablePolicyState 2^>nul ^| find "REG_DWORD"') do set "SAC=%%A"
if /i "%SAC%"=="0x1" goto sacon
if /i "%SAC%"=="0x2" goto saceval
goto install

:saceval
echo [WARNING] Smart App Control is in Evaluation mode on this PC.
echo Installation will continue, but Python will be blocked if Windows turns it On later.
echo To avoid this, see "Before you start" in setup_guide and turn it Off.
echo.

:install
echo [1/3] Installing Python 3.14 ...
uv.exe python install 3.14
if errorlevel 1 goto fail

echo.
echo [2/3] Creating the virtual environment .venv ...
uv.exe venv --python 3.14 --seed --clear
if errorlevel 1 goto fail

echo.
echo [3/3] Installing libraries. This takes a few minutes ...
uv.exe pip install --python .venv -r requirements.txt
if errorlevel 1 goto fail

echo.
echo [Check] Loading the libraries ...
.venv\Scripts\python.exe -c "import numpy, pandas, scipy, sklearn, statsmodels, matplotlib, seaborn, pingouin, notebook"
if errorlevel 1 goto blocked
.venv\Scripts\python.exe --version
echo.
echo Done. Double-click start_jupyter.bat to open Jupyter Notebook.
pause
exit /b 0

:sacon
echo [ERROR] Smart App Control is On. It blocks the Python libraries used in this course.
echo Nothing was installed.
echo Turn it Off as shown in "Before you start" in setup_guide, then run install.bat again.
pause
exit /b 1

:nouv
echo [ERROR] uv.exe not found in %~dp0
echo See the troubleshooting table in setup_guide.
pause
exit /b 1

:blocked
echo.
echo [ERROR] Python was installed, but the libraries could not be loaded.
echo A security feature or program on this PC may be blocking them.
echo Take a screenshot of this window and see the troubleshooting table in setup_guide.
pause
exit /b 1

:fail
echo.
echo [ERROR] Installation stopped at the step above.
echo Take a screenshot of this window and see the troubleshooting table in setup_guide.
pause
exit /b 1
